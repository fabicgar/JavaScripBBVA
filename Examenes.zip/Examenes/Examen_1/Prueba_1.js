// Numeros Aleatorios
function generarNumeroAleatorioEntre(minimo, maximo) {
    var anchoFranjaNumerica = (maximo - minimo) + 1;
    var numero = Math.floor((Math.random() * anchoFranjaNumerica) + minimo);

    return numero;
}

function Biblioteca(nombre) {
    this._nombre = nombre;
    this._secciones = [];
    this._socios = [];

};
Biblioteca.prototype.agregarSeccionaBiblioteca = function(Seccion) {
    this._secciones.push(seccion);

}



function Libros(nombre, NumeroDePaginas, Autor, Tematica) {
    this._nombre = nombre;
    this._NumeroDePaginas = NumeroDePaginas;
    this._Autor = Autor;
    this._Tematica = Tematica;
}


function Seccion(nombre, libros) {
    this._nombre = nombre;
    this._libros = [];
}

//socio
function crearsocioAleatorio(nombre, numerodesocio, libros) {
    this._nombre = generarNombreAleatorio(),
        this._numerodesocio = generarNumeroAleatorioEntre(1, 100),
        this.libros = [],
};

crearsocioAleatorio.prototype.generarNombreAleatorio = function() {
    var nombressocios = ["Carlos", "Daniel", "Fabian", "Juan Carlos", "Bryan", "Saul", "Christian", "Marcel", "Ronal", "David", "Fran"];
    var indice = generarNumeroAleatorioEntre(0, nombresNegados.length - 1);

    return nombressocios[indice];
}



//Crear Biblioteca

var biblioteca = new Biblioteca("Biblioteca FCGR");

// crear secciones

var seccionAmor = new Seccion("Amor");
var seccionAmor = new Seccion("Aventuras");
var seccionAmor = new Seccion("Naturaleza");
var seccionAmor = new Seccion("Historia");
var seccionAmor = new Seccion("Viajes");

Biblioteca.agregarSeccionaBiblioteca(Amor);
Biblioteca.agregarSeccionaBiblioteca(Aventuras);
Biblioteca.agregarSeccionaBiblioteca(Naturaleza);
Biblioteca.agregarSeccionaBiblioteca(Historia);
Biblioteca.agregarSeccionaBiblioteca(Viajes);



console.log(biblioteca);