class SuperHeroesApiClient{

	constructor(apiClient){
		this._baseUrl = "https://ironhack-characters.herokuapp.com/characters";
		this._apiClient = apiClient;
	}

	// Este método devuelve una promesa
	// que se resuelve con un array de objetos SuperHeroe
	getAllSuperHeroes(){
		let completeUrl = this._baseUrl;
		let promise = this._apiClient.get(completeUrl, null);

		let anotherPromise = promise.then((data) => {
			let superHeroes = [];

			for(let i=0; i<data.length; i ++){
				let elemento = data[i];
				let superHeroe = new SuperHeroe(
					elemento.id,
					elemento.name,
					elemento.weapon,
					elemento.occupation,
					elemento.debt
				);
				superHeroes.push(superHeroe);
			}

			return superHeroes;
		});

		return anotherPromise;
	}

	createSuperHeroe(superHeroe){

	}

	editSuperHeroe(superHeroe){

	}

	deleteSuperHeroe(superHeroe){

	}
}